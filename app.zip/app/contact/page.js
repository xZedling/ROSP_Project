import Contact from "./Contact";

const page = () => {
  return (
    <div>
      <Contact />
    </div>
  );
};

export default page;
