import Login from "./Login";

const page = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default page;
