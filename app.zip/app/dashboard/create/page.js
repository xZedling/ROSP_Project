import Form from "../Form";

const page = () => {
  return (
    <div className="w-full">
      <Form />
    </div>
  );
};

export default page;
